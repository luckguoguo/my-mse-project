package cn.edu.sjtu.petclinic.service.impl;

import org.springframework.stereotype.Service;

import cn.edu.sjtu.petclinic.service.DictionaryService;

@Service
public class DictionaryServiceImpl extends AbstractService implements DictionaryService {

}
