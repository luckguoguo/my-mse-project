package cn.edu.sjtu.petclinic.enums;

public enum Gender {

	MALE, FEMALE
	
}
