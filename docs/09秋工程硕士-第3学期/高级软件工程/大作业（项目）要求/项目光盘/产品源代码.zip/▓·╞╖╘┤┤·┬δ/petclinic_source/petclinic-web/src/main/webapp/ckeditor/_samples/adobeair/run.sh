#!/usr/bin/env bash

# Copyright (c) 2003-2010, CKSource - Frederico Knabben. All rights reserved.
# For licensing, see LICENSE.html or http://ckeditor.com/license

# Use this file to quickly run the sample under Linux.

adl application.xml ../../
