package cn.edu.sjtu.petclinic.service;

public interface DictionaryService {

}
